package com.se.device;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
